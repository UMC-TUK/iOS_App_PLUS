//
//  ViewController.swift
//  UMC_10thweekmission
//
//  Created by 신예진 on 2023/06/18.
//

import UIKit
import FirebaseAuth
import GoogleSignIn
import Firebase
import KakaoSDKAuth
import KakaoSDKUser

class ViewController: UIViewController{
    
    
    @IBOutlet weak var signInButton: GIDSignInButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction func googleLogin(_ sender: GIDSignInButton) {
            // 구글 인증
            guard let clientID =
                    FirebaseApp.app()?.options.clientID
        else { return }
        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config
            
        GIDSignIn.sharedInstance.signIn(withPresenting: self) { [unowned self] result, error in
                guard error == nil else { return }
                
                // 인증을 해도 계정은 따로 등록을 해주어야 한다.
                // 구글 인증 토큰 받아서 -> 사용자 정보 토큰 생성 -> 파이어베이스 인증에 등록
                guard
                   let user = result?.user,
                   let idToken = user.idToken?.tokenString
                 else {
                   return
                 }
                 let credential = GoogleAuthProvider.credential(withIDToken: idToken,
                                                                accessToken: user.accessToken.tokenString)
                
                // 사용자 정보 등록
                Auth.auth().signIn(with: credential) { result, error in
                    // 사용자 등록 후에 처리할 코드
                }
                // If sign in succeeded, display the app's main content View.
              }
        }
    
    @IBAction func kakaoLoginTouched(_ sender: UIButton) {
      UserApi.shared.loginWithKakaoAccount() { (oAuthToken, error) in
        if let error = error {
          print(error)
        } else {
          print("loginWithKakaoAccount success")
          _ = oAuthToken
          guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "homeVC")
                  as? HomeViewController else { return }
          vc.modalPresentationStyle = .fullScreen
          self.present(vc, animated: true)
        }
      }
    }
    
}
