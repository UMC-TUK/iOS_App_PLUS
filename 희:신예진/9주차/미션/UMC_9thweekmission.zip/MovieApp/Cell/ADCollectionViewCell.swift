//
//  ADCollectionViewCell.swift
//  MovieApp
//
//  Created by 신예진 on 2023/01/19.
//

import Foundation
import UIKit

class ADCollectionViewCell: UICollectionViewCell {
  @IBOutlet weak var imgView: UIImageView!
}
