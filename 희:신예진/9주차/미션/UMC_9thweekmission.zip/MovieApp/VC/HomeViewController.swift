//
//  HomeViewController.swift
//  MovieApp
//
//  Created by 신예진 on 2023/01/18.
//

import UIKit
import KakaoSDKUser

class HomeViewController: UIViewController {
  // MARK: - LifeCycles
  override func viewDidLoad() {
    super.viewDidLoad()
  }
}


